#include "position.h"

Position::Position(double xPos, double yPos)
{
  x = xPos;
  y = yPos;
}

Position::~Position()
{
}

double Position::getAngle(Position* target)
{
  return atan2((target->y - y),(target->x - x));
}

double Position::getDistance(Position* target)
{
  return sqrt((pow(target->y - y,2.0)) + (pow(target->x - x,2.0)));
}

Position Position::operator+(const Position &other) const
{
   Position result = *(new Position(x+other.x, y+other.y));
   return result;
} 

Position Position::operator-(const Position &other) const
{
   Position result = *(new Position(x-other.x, y-other.y));
   return result;
} 

Position Position::times(double r){
  return *(new Position(r*x, r*y));
}

double Position::getAbs()
{
  return sqrt((pow(y,2.0)) + (pow(x,2.0)));
}
