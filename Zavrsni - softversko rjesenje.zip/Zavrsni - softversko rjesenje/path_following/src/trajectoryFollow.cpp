#include "trajectoryFollow.h"
#include <cmath>

TrajectoryFollow::TrajectoryFollow(ros::Publisher pub, TrajectoryFollowingParams params) : 
  pubMessage(pub), parameters(params)
{
  if (parameters.look_ahead < 2*parameters.tolerance){
    ROS_INFO("look_ahead must be bigger than 2*tolerance");
    exit(1);
  }
  lastRemoved = new Position(0.0, 0.0);
  target = new Position(0.0, 0.0); 
  danger_angle = 0;
  danger_distance = 0;
  notReceived = true;
}

TrajectoryFollow::~TrajectoryFollow()
{
}

void TrajectoryFollow::trajectoryCallBack(const nav_msgs::Path::ConstPtr& msg)
{
  ROS_INFO("Trajectory received! Following...");
  notReceived = false;
  while (trajectory.size()>0)
  {
    trajectory.pop();
  }
  
  ros::Duration(0.1).sleep();
  tf::StampedTransform transform;
  try{
    listener.lookupTransform(parameters.path_frame, parameters.odom_frame, ros::Time(0), transform);
  }
  catch (tf::TransformException ex){
    ROS_ERROR("%s",ex.what());
    return;
  }
  double phi = 2.0*asin(transform.getRotation().z());
  std::vector<geometry_msgs::PoseStamped> data = msg->poses;
  for(std::vector<geometry_msgs::PoseStamped>::iterator it = data.begin(); it != data.end(); ++it) {
    double x_t = it->pose.position.x - transform.getOrigin().x(); //translation
    double y_t = it->pose.position.y - transform.getOrigin().y(); //translation
    double x_r = x_t*cos(phi) + y_t*sin(phi);
    double y_r = -x_t*sin(phi) + y_t*cos(phi);
    trajectory.push(new Position(x_r,y_r));
  }
}

void TrajectoryFollow::laserCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
  //ROS_INFO("Laser data received!");
  int size = msg->ranges.size();
  int minIndex = 0;
  for(int i=minIndex; i<size; i++)
  {
    if (msg->ranges[i] < msg->ranges[minIndex] && msg->ranges[i] > parameters.skip_sensor_dist){
      minIndex = i;
    }
  }
  danger_angle = (minIndex-size/2)*msg->angle_increment;
  danger_distance = msg->ranges[minIndex];

  ros::Duration(0.1).sleep();
  tf::StampedTransform transform;
  try{
    listener.lookupTransform(parameters.odom_frame, parameters.robot_frame, ros::Time(0), transform);
  }
  catch (tf::TransformException ex){
    ROS_ERROR("%s",ex.what());
    return;
  }
  robotLocation.position.x = transform.getOrigin().x();
  robotLocation.position.y = transform.getOrigin().y();
  robotLocation.position.z = transform.getOrigin().z();
  robotLocation.orientation.x = transform.getRotation().x();
  robotLocation.orientation.y = transform.getRotation().y();
  robotLocation.orientation.z = transform.getRotation().z();
  robotLocation.orientation.w = transform.getRotation().w();

  double angleCommand = 0;
  double speedCommand = 0;
  Position* actual = new Position(robotLocation.position.x, robotLocation.position.y);

  if (fabs(lastRemoved->x) < 0.0001 && fabs(lastRemoved->y) < 0.0001 && trajectory.size()>0)
  {
    lastRemoved->x = actual->x;
    lastRemoved->y = actual->y;
    return;
  }
  findTarget(actual);
  if (closeEnough(actual) == true && trajectory.empty())
  {
    publishMessage(0.0,0.0);
      
    if(parameters.stop_at_target){
      }
  }
  angleCommand = calculateAngErr(actual, tf::getYaw(robotLocation.orientation));
  if (fabs(angleCommand) > 1.0)
  {
    speedCommand = 0;
  }
  else if (fabs(angleCommand) > 0.5)
  {
    speedCommand = parameters.max_linear_velocity/2;
  }
  else
  {
    speedCommand = parameters.max_linear_velocity;
  }
  double angleVel = avoidCollisionAngle(angleCommand, speedCommand);
  double linearVel = avoidCollisionSpeed(angleCommand, speedCommand);
  ROS_INFO("Publishing command [%.2f ; %.2f]", linearVel, angleVel);
  
  publishMessage(angleVel, linearVel);
  ROS_INFO("Action published!");
}

void TrajectoryFollow::publishMessage(double angleCommand, double speedCommand)
{
  //ROS_INFO("Going with: [%.2f ; %.2f]", speedCommand, angleCommand);
  geometry_msgs::Twist msg;

  msg.linear.x = speedCommand;
  double value = fabs(fmin(parameters.max_angular_velocity, fabs(angleCommand*parameters.angle_to_velocity)));
  if (angleCommand < 0)
    value *= -1;

  msg.angular.z = value;  
  pubMessage.publish(msg);
  //ROS_INFO("Published twist command!");
}

double TrajectoryFollow::calculateAngErr(Position* actual, double angle)
{
  double angleCalc;
  angleCalc = actual->getAngle(target)-angle;
  if (fabs(angleCalc)>M_PI)
  {
    angleCalc = angleCalc - copysign(2*M_PI,angleCalc);
  }
  return angleCalc;
}

bool TrajectoryFollow::closeEnough(Position* actual)
{
  double distance;
  distance = actual->getDistance(target);
  if (distance > parameters.tolerance)
  {
    return false;
  }
  return true;
}

void TrajectoryFollow::findTarget(Position* actual)
{
  if (trajectory.empty() == false)
  {
  while (actual->getDistance(trajectory.front()) < parameters.look_ahead)
  {
    lastRemoved = trajectory.front();
    trajectory.pop();
    if(trajectory.empty() == true){
      break;
    }
  }
  }
  if (trajectory.empty() == true)
  {
    target->x = lastRemoved->x;
    target->y = lastRemoved->y;
  }
  else
  {  
    Position* s = new Position(trajectory.front()->x - lastRemoved->x, trajectory.front()->y - lastRemoved->y);

    Position* v = new Position(0.0,0.0);
    if (actual->getDistance(lastRemoved) >= parameters.look_ahead && actual->getDistance(trajectory.front()) >= parameters.look_ahead && 
    (lastRemoved->x != trajectory.front()->x || lastRemoved->y != trajectory.front()->y))  
    {
      double a, b, c, dist;
      a = lastRemoved->y - trajectory.front()->y;
      b = trajectory.front()->x - lastRemoved->x;  
      c = lastRemoved->x * trajectory.front()->y - trajectory.front()->x * lastRemoved->y;
      if (a * a + b * b < 0.001)  
      {
        target->x = lastRemoved->x;
        target->y = lastRemoved->y;
        return;
      }    
      dist = fabs(a*actual->x + b*actual->y + c)/sqrt(a * a + b * b);  
      double distFromLast;
      distFromLast = sqrt(pow(lastRemoved->getDistance(actual),2.0) - pow(dist,2.0));
      v->x = (distFromLast/s->getAbs())*s->x;
      v->y = (distFromLast/s->getAbs())*s->y;
      s->x = s->x - v->x;
      s->y = s->y - v->y;
    }

    for (int i = 1; i < parameters.approx_iterations; i++)
    {
      if ((*lastRemoved + s->times(pow(2,-i)) + *v - *actual).getAbs() < parameters.look_ahead)
      {
        *v = *v + s->times(pow(2,-i));
      }

    }
    target->x = lastRemoved->x + v->x;
    target->y = lastRemoved->y + v->y;
  }
}

double TrajectoryFollow::avoidCollisionAngle(double angleCommand, double speedCommand)
{
  if (trajectory.size() == 0)
    return 0;
  if (speedCommand < 0.001)  
  {
    return angleCommand;
  }
  else if (danger_distance < parameters.avoid_distance_front && fabs(danger_angle) < M_PI/6.0)  
  {
    return copysign(0.3,-danger_angle);
  }
  else if (danger_distance < parameters.avoid_distance_side && fabs(danger_angle) < 4.0*M_PI/6.0)  
  {
    return copysign(0.2,-danger_angle);
  }
  else
  {
    return angleCommand;
  }
}

double TrajectoryFollow::avoidCollisionSpeed(double angleCommand, double speedCommand)
{
  if (speedCommand < 0.001)  
  {
    return speedCommand;
  }
  else if (danger_distance < parameters.avoid_distance_front && danger_distance >= parameters.avoid_distance_side && fabs(danger_angle) < M_PI/6.0) 
  {
    return 0.8*speedCommand;
  }
  else if (fabs(danger_angle) < 4.0*M_PI/6.0 && danger_distance < parameters.avoid_distance_side)  
  {
    return 0.6*speedCommand;
  }
  else
  {
    return speedCommand;
  }
}
