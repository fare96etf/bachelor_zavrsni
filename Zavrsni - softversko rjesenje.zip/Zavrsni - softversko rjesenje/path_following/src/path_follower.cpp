#include "trajectoryFollow.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "following");
  ros::NodeHandle n;
  TrajectoryFollowingParams params;
  if (!n.getParam("tolerance", params.tolerance))
    params.tolerance = 0.05;
  if (!n.getParam("max_linear_velocity", params.max_linear_velocity))
    params.max_linear_velocity = 0.9;
  if (!n.getParam("max_angular_velocity", params.max_angular_velocity))
    params.max_angular_velocity = 0.5;
  if (!n.getParam("look_ahead", params.look_ahead))
    params.look_ahead = 0.2;
  if (!n.getParam("angle_to_velocity", params.angle_to_velocity))
    params.angle_to_velocity = 2.0;
  if (!n.getParam("skip_sensor_dist", params.skip_sensor_dist))
    params.skip_sensor_dist = 0.06;
  if (!n.getParam("avoid_distance_front", params.avoid_distance_front))
    params.avoid_distance_front = 0.2;
  if (!n.getParam("avoid_distance_side", params.avoid_distance_side))
    params.avoid_distance_side = 0.14;
  if (!n.getParam("approx_iterations", params.approx_iterations))
    params.approx_iterations = 10;
  if (!n.getParam("stop_at_target", params.stop_at_target))
    params.stop_at_target = true;
  if (!n.getParam("path", params.path))
    params.path = "/path";
  if (!n.getParam("scan", params.scan))
    params.scan = "/base_scan";
  if (!n.getParam("cmd_vel", params.cmd_vel))
    params.cmd_vel = "/cmd_vel";
  if (!n.getParam("path_frame", params.path_frame))
    params.path_frame = "/map"; //map bilo
  if (!n.getParam("robot_frame", params.robot_frame))
    params.robot_frame = "/base_link";
  if (!n.getParam("odom_frame", params.odom_frame))
    params.odom_frame = "/odom";

  ros::Publisher velPub = n.advertise<geometry_msgs::Twist>(params.cmd_vel, 1);

  TrajectoryFollow *trajectoryFollow = new TrajectoryFollow(velPub, params);
  ROS_INFO("Follower started!");
  ros::Subscriber trajSub = n.subscribe(params.path, 1, &TrajectoryFollow::trajectoryCallBack, trajectoryFollow);
  ros::Subscriber lasSub = n.subscribe(params.scan, 1, &TrajectoryFollow::laserCallback, trajectoryFollow);

  ros::spin();
  return 0;
}
