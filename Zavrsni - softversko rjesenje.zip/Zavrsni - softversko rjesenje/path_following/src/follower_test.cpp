#include "ros/ros.h"
#include "std_msgs/String.h"
#include "nav_msgs/Path.h"
#include "geometry_msgs/PoseStamped.h"

int main(int argc, char **argv)
{
  ros::init(argc, argv, "follower_test");
  ros::NodeHandle n;
  ros::Publisher pathPub = n.advertise<nav_msgs::Path>("/path", 1);
  ros::Rate loop_rate(10);
  
  std::vector<geometry_msgs::PoseStamped> poses(3);
  nav_msgs::Path path;
  poses.at(0).pose.position.x = 1; //0.1
  poses.at(0).pose.position.y = 1; // 5

  poses.at(1).pose.position.x = 3; //1.5
  poses.at(1).pose.position.y = 2; // 2.5

  poses.at(2).pose.position.x = 0;
  poses.at(2).pose.position.y = 0;

  path.poses = poses;  
  int count = 0;

  while(ros::ok()) {
    if (count < 2)
      pathPub.publish(path);
    ros::spinOnce();
    loop_rate.sleep();
    ++count;
  }
  return 0;
}
