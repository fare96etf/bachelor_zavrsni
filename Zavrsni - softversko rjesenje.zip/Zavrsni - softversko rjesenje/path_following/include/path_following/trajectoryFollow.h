#include "position.h"
#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/Path.h"
#include <queue>
#include "tf/tf.h"
#include "tf/transform_listener.h"

struct TrajectoryFollowingParams{
  double tolerance, max_linear_velocity, max_angular_velocity,
    look_ahead, angle_to_velocity, skip_sensor_dist,
    avoid_distance_front, avoid_distance_side;
  int approx_iterations;
  bool stop_at_target;
  std::string path, scan, cmd_vel, path_frame, robot_frame, odom_frame;
};

class TrajectoryFollow
{
public:

    TrajectoryFollow(ros::Publisher pub, TrajectoryFollowingParams params);

    ~TrajectoryFollow();
	  void publishMessage(double angleCommand, double speedCommand);
    void laserCallback(const sensor_msgs::LaserScan::ConstPtr& msg);
    double calculateAngErr(Position* actual, double angle);
    bool closeEnough(Position* actual);
    void findTarget(Position* actual);
    void trajectoryCallBack(const nav_msgs::Path::ConstPtr& msg);
    double avoidCollisionSpeed(double angleCommand, double speedCommand);
    double avoidCollisionAngle(double angleCommand, double speedCommand);

    std::queue<Position*> trajectory; 
    Position* lastRemoved;  
    Position* target;    
    ros::Publisher pubMessage; 
    double danger_angle;
    double danger_distance;
    tf::TransformListener listener;
    geometry_msgs::Pose robotLocation;
    TrajectoryFollowingParams parameters; 
    bool notReceived;
};
