#include <math.h> 

class Position
{
public:

  Position(double xPos, double yPos);
  ~Position();

  double getAngle(Position* target);
  double getDistance(Position* target);
  Position operator+(const Position &other) const;
  Position operator-(const Position &other) const;
  Position times(double r);
  double getAbs();

  double x; 
  double y; 
};
