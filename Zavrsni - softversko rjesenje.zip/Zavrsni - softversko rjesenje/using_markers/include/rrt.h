#include <iostream>
#include <vector>
#include <random>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/MapMetaData.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Pose.h>
#include <tf/transform_listener.h> 
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <Eigen/Dense>

#define PI 3.14159265358979323846264

using namespace std;
using namespace Eigen;
 
typedef vector<double> Koordinate;

int g(0);

// klasa Tacka

class Tacka {
    Koordinate koord;


public:
    Tacka *parent;
    Tacka(Koordinate k) { koord = k; parent = nullptr; }
    Koordinate Daj_Koordinate() {return koord;};
    void Dodijeli_Parent(Tacka *t) { parent = t;}
};

// klasa RRT

class SRRT {

    vector<Tacka> Stablo;
    vector<Tacka> Putanja;
    sensor_msgs::LaserScan senzor;
    double duzina = 0;
    Koordinate init;
    Koordinate goal{0, 0};
	    	
    Koordinate Generisi_Koordinate(double delta, long int i, Koordinate goal);	
    double Random_generator();

public:
    
    void Generisi_Stablo(Tacka x_init,Tacka x_goal, double delta, long int broj_iteracija, sensor_msgs::LaserScan senzor1);
    void Ocisti_Stablo() { Stablo.clear(); }
    void Ocisti_Putanju() { Putanja.clear(); }
    int BrojTacakaStabla() {return Stablo.size(); }
    void Dodaj(Tacka t) { Stablo.push_back(t); }
    vector<Tacka> DajStablo () {return Stablo;}
    vector<Tacka> DajPutanju () {return Putanja;}
    double DajDuzinu() { return duzina; }
    double Izracunaj_udaljenost(Koordinate x, Koordinate y);	

    Tacka* Najbliza_tacka(Tacka t);	
	 

};

// GLAVNA FUNKCIJA, generise stablo

void SRRT::Generisi_Stablo(Tacka x_init,Tacka x_goal, double delta, long int broj_iteracija, sensor_msgs::LaserScan senzor1) {

    senzor = senzor1;
    goal[0] = x_goal.Daj_Koordinate()[0];
    goal[1] = x_goal.Daj_Koordinate()[1];		
    Putanja.push_back(x_init);
    int provjera(0);	     
   		
    for (long int i = 0; i < broj_iteracija; i++) {
	    g = i;
            Tacka t(Generisi_Koordinate(delta, i, goal));	
	    if (t.Daj_Koordinate().size() > 0) {
		t.Dodijeli_Parent(Najbliza_tacka(x_init));	
            	Stablo.push_back(t);
		Putanja.push_back(t);
		duzina+=Izracunaj_udaljenost(Putanja[0].Daj_Koordinate(), Putanja[1].Daj_Koordinate());
		provjera = 1;
            	break;	
	    }
    }
    if (provjera == 0) { Putanja.push_back(*Najbliza_tacka(x_init)->parent); duzina+=Izracunaj_udaljenost(Putanja[0].Daj_Koordinate(), Putanja[1].Daj_Koordinate()); }			
    
}

// generisi koordinate

Koordinate SRRT::Generisi_Koordinate(double delta, long int i, Koordinate goal) {
    
    	Koordinate k;
  			    		
    	k.push_back(Random_generator());
    	k.push_back(Random_generator()); 

    	double alpha (atan2(k[1], k[0]));
    	if (alpha < senzor.angle_min || alpha > senzor.angle_max) { k.clear(); return k; }	
    
    	double r(senzor.ranges[0]);
	int duzina_niza(int((senzor.angle_max-senzor.angle_min)/senzor.angle_increment+0.5));     
    	double y ((alpha-senzor.angle_min)/senzor.angle_increment+0.5);
    	int y1 = int(y);
   			
    	if (senzor.ranges[y1] > senzor.range_max) r = senzor.range_max;
    	else r = senzor.ranges[y1];
    	/*for (int i = 1; i < int((senzor.angle_max-senzor.angle_min)/senzor.angle_increment+0.5); i++) {
		if (senzor.ranges[i] < r) r = senzor.ranges[i];
    	}*/
	if (y1 < 49 || y1 > duzina_niza-50) { k.clear(); return k; }
	if (y1 > 49 && y1 < duzina_niza-50) {
		for(int i = y1-50; i <= y1+50; i++) {
			if (senzor.ranges[i] < r) { k.clear(); return k; }
		}		
	}
	
    	if (r < 2.5) { k.clear(); return k; } //za 0.3: r < 1, 0.6: r < 2, 0.5: r<2.5				
	
   	k[0] = r*delta*cos(alpha);
	k[1] = r*delta*sin(alpha);
       
    	ROS_INFO ("alpha: %f, lsr: %f", alpha, r*delta);
	
	tf::TransformListener listener;
    	tf::StampedTransform transform;
  			
 	try {
	    	ros::Time now = ros::Time::now();
    		listener.waitForTransform("/map", "/base_laser_link", now, ros::Duration(1.0));
    		listener.lookupTransform("/map", "/base_laser_link", ros::Time(0), transform);
    	}
   	catch (tf::TransformException &ex) {
    		ROS_ERROR("%s",ex.what());
    		ros::Duration(0.5).sleep();
		ROS_INFO("Transformacija nije uspjela!");
    	}
    	
	double l0 (k[0]);
	double l1 (k[1]);
    	double pomak_x (transform.getOrigin().x());
    	double pomak_y (transform.getOrigin().y());
    	double R00 (transform.getBasis()[0][0]);
    	double R01 (transform.getBasis()[0][1]);
    	double R10 (transform.getBasis()[1][0]);
    	double R11 (transform.getBasis()[1][1]);	
	
	if (i == 0) {
		k[0] = goal[0];
		k[1] = goal[1];
	}
	else {
		k[0] = pomak_x + R00*l0+R01*l1;
		k[1] = pomak_y + R10*l0+R11*l1;
	}	

	//k[0] = pomak_x + R00*l0+R01*l1;
	//k[1] = pomak_y + R10*l0+R11*l1;     	
	
    	return k;
}


// odredi najblizu tacku iz stabla

Tacka* SRRT::Najbliza_tacka(Tacka t) {
    double dmin = Izracunaj_udaljenost(Stablo[0].Daj_Koordinate(), t.Daj_Koordinate());
    Tacka *najbliza = new Tacka(Stablo[0]);

    for (int i = 1; i < Stablo.size(); i++) {

        if (Izracunaj_udaljenost(Stablo[i].Daj_Koordinate(), t.Daj_Koordinate()) < dmin) {
            dmin = Izracunaj_udaljenost(Stablo[i].Daj_Koordinate(), t.Daj_Koordinate());
            *najbliza = Stablo[i];
        }

    }

    return najbliza;
}

// pomocne funkcije i interfejs

double SRRT::Izracunaj_udaljenost(Koordinate x, Koordinate y) {
    double d = 0;

    for (int i = 0; i < x.size(); i++) {
        d += (y[i]-x[i])*(y[i]-x[i]);
    }
    return sqrt(d);
}


double SRRT::Random_generator() {
 
   std::random_device rd;  //Will be used to obtain a seed for the random number engine
   std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
   std::uniform_real_distribution<> dis(-15.0, 15.0);
   return dis(gen);
}
















