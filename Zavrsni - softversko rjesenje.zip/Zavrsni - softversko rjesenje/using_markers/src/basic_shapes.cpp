#include "rrt.h"

nav_msgs::Odometry polozaj;
nav_msgs::Odometry polozaj1;
nav_msgs::OccupancyGrid mapa;
geometry_msgs::PoseStamped GOAL;
sensor_msgs::LaserScan senzor;
sensor_msgs::LaserScan senzor1;
geometry_msgs::Twist brzina;
SRRT rrt;
Tacka t2({GOAL.pose.position.x, GOAL.pose.position.y});
auto start = std::chrono::system_clock::now();
int brojac = 0;
long int k = 0;

void OdomCallback(const nav_msgs::Odometry::ConstPtr& msg){
	polozaj = *msg; 
}

void GridCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg){
	mapa = *msg;
	
}

void BrzinaCallback(const geometry_msgs::Twist::ConstPtr& msg){
	brzina = *msg;
	if (brzina.linear.x == 0 && brzina.linear.y == 0 && brzina.angular.x == 0 && brzina.angular.z == 0) brojac++;
	else brojac = 0;	
}


void SenzorCallback(const sensor_msgs::LaserScan::ConstPtr& msg){

senzor = *msg;
if (senzor1.ranges != senzor.ranges && brojac == 10) {
	k++;
	if (k == 1) start = std::chrono::system_clock::now();
	ROS_INFO("K: %lu", k);	
	senzor1 = senzor;
	brojac = 0;
	ros::NodeHandle n2;
	ros::Publisher path_pub = n2.advertise<nav_msgs::Path>("/path", 1);
  	
	tf::TransformListener listener;
    	tf::StampedTransform transform;
  			
 	try {
	    	ros::Time now = ros::Time::now();
    		listener.waitForTransform("/map", "/odom", now, ros::Duration(1.0));
    		listener.lookupTransform("/map", "/odom", ros::Time(0), transform);
    	}
   	catch (tf::TransformException &ex) {
    		ROS_ERROR("%s",ex.what());
    		ros::Duration(0.5).sleep();
		ROS_INFO("Transformacija nije uspjela!");
    	}

	double odom_x (polozaj.pose.pose.position.x);
	double odom_y (polozaj.pose.pose.position.y);    	
    	double pomak_x (transform.getOrigin().x());
    	double pomak_y (transform.getOrigin().y());
    	double R00 (transform.getBasis()[0][0]);
    	double R01 (transform.getBasis()[0][1]);
    	double R10 (transform.getBasis()[1][0]);
    	double R11 (transform.getBasis()[1][1]);	
	
	double x (pomak_x + R00*odom_x+R01*odom_y);
	double y (pomak_y + R10*odom_x+R11*odom_y);

	Tacka t1({x, y});
			 		
	if (k == 1) rrt.Dodaj(t1); 		
	try{
		rrt.Generisi_Stablo(t1, t2, 0.5, 5000, senzor); //ulazni podaci
    	}
    	catch (exception ex) {
      		ROS_ERROR("%s",ex.what());
      	}
			
	nav_msgs::Path putanja;
	putanja.header.frame_id = "/map";
	putanja.header.stamp = ros::Time::now();  		
	
	geometry_msgs::Point p1;	
	geometry_msgs::PoseStamped pozicija;
			
	p1.x = rrt.DajPutanju()[0].Daj_Koordinate()[0];
	p1.y = rrt.DajPutanju()[0].Daj_Koordinate()[1];
 
	pozicija.pose.position = p1;
	putanja.poses.push_back(pozicija);

	p1.x = rrt.DajPutanju()[1].Daj_Koordinate()[0];
	p1.y = rrt.DajPutanju()[1].Daj_Koordinate()[1];
 
	pozicija.pose.position = p1;
	putanja.poses.push_back(pozicija);

	rrt.Ocisti_Putanju();
	path_pub.publish(putanja);

	auto end = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds = end-start;
    	std::time_t end_time = std::chrono::system_clock::to_time_t(end);
 
	ROS_INFO ("goal_X: %f", GOAL.pose.position.x);
    	ROS_INFO ("elapsed time: %f", elapsed_seconds.count());
	ROS_INFO ("duzina: %f", rrt.DajDuzinu());			
    	ROS_INFO ("broj node-ova: %lu, broj iteracija: %lu", rrt.DajStablo().size(), k);

} // kraj if petlje

//ukloniti komentar koji se nalazi ispod za SRT-Goal

/*tf::TransformListener listener1;   
tf::StampedTransform transform1;
  			
try {
    	ros::Time now1 = ros::Time::now();
	listener1.waitForTransform("/base_laser_link", "/map", now1, ros::Duration(1.0));
	listener1.lookupTransform("/base_laser_link", "/map", ros::Time(0), transform1);
}
catch (tf::TransformException &ex) {
	ROS_ERROR("%s",ex.what());
	ros::Duration(0.5).sleep();
	ROS_INFO("Transformacija nije uspjela!");
}
    	
double l0 (GOAL.pose.position.x);
double l1 (GOAL.pose.position.y);
double pomak_x2 (transform1.getOrigin().x());
double pomak_y2 (transform1.getOrigin().y());
double R002 (transform1.getBasis()[0][0]);
double R012 (transform1.getBasis()[0][1]);
double R102 (transform1.getBasis()[1][0]);
double R112 (transform1.getBasis()[1][1]);

int provjera(0);
double ugao (atan2(pomak_y2 + R102*l0+R112*l1, pomak_x2 + R002*l0+R012*l1));

double y ((ugao-senzor.angle_min)/senzor.angle_increment+0.5);
int y1 = int(y);
   			
if (ugao > senzor.angle_min && ugao < senzor.angle_max && senzor.ranges[y1] > rrt.Izracunaj_udaljenost({0, 0}, {pomak_x2 + R002*l0+R012*l1, pomak_y2 + R102*l0+R112*l1})) provjera = 1;*/

if (k == 100 /*|| prepreka == 1*/) { // ukloniti komenta u zagradi za SRT-Goal, parametar k je Kmax			
	
	rrt.Dodaj(t2);	 

	ros::NodeHandle n1;
  	ros::Publisher marker_pub = n1.advertise<visualization_msgs::Marker>("visualization_marker", 1);	
	
	visualization_msgs::Marker points, line_list;
 	points.header.frame_id = line_list.header.frame_id = "/map";
   	points.header.stamp = line_list.header.stamp = ros::Time::now();
    	points.ns = line_list.ns = "points_and_lines";
   	points.action = line_list.action = visualization_msgs::Marker::ADD;
   	points.pose.orientation.w = line_list.pose.orientation.w = 1.0;
	
    	points.id = 0;
        line_list.id = 2;
	
    	points.type = visualization_msgs::Marker::POINTS;
    	line_list.type = visualization_msgs::Marker::LINE_LIST;
	
    	points.scale.x = 0.07;
    	points.scale.y = 0.07;
	
    	line_list.scale.x = 0.01;
	
    	points.color.b = 1.0f;
    	points.color.a = 1.0;
	
    	line_list.color.r = 1.0f;
    	line_list.color.a = 1.0;
     	
	
    	points.lifetime = ros::Duration();
	line_list.lifetime = ros::Duration();
	
      	geometry_msgs::Point p1;
	p1.x = rrt.DajStablo()[0].Daj_Koordinate()[0];
	p1.y = rrt.DajStablo()[0].Daj_Koordinate()[1];
      	p1.z = 0;
	points.points.push_back(p1);	

  	for (int h = 1; h < rrt.DajStablo().size(); h++) {  // krece od 1 zato sto prvi parent je nullptr 
	
     		geometry_msgs::Point p;
				
		p.x = rrt.DajStablo()[h].Daj_Koordinate()[0];
		p.y = rrt.DajStablo()[h].Daj_Koordinate()[1];
      		p.z = 0;
				
		points.points.push_back(p);
      		if (h != rrt.DajStablo().size()-1) {
			line_list.points.push_back(p);
		
			p.x = (rrt.DajStablo()[h].parent)->Daj_Koordinate()[0];
			p.y = (rrt.DajStablo()[h].parent)->Daj_Koordinate()[1];
      		        line_list.points.push_back(p);
		}
    	}
	
    	while (marker_pub.getNumSubscribers() < 1)
    	{
    	ROS_WARN_ONCE("Please create a subscriber to the marker");
     		sleep(1);
    	}
    	marker_pub.publish(points);
    	marker_pub.publish(line_list);

	/*if (provjera == 1) ROS_INFO("Tacka je pronadjena."); // ukloniti komentar za SRT-Goal
	else ROS_INFO("Tacka nije pronadjena.");*/
	ROS_INFO("KRAJ");	
    
	ros::shutdown();
	} // kraj drugog if-a 			
					
}

void GoalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg){
	GOAL = *msg;	
}


int main( int argc, char** argv )
{
  
		

	ros::init(argc, argv, "basic_shapes");
  	ros::NodeHandle n1;
	ros::NodeHandle n2;
	ros::NodeHandle n3;
	ros::NodeHandle n4;
	ros::NodeHandle n5;
		 	
	ros::Subscriber sub1 = n1.subscribe("/odom", 10, OdomCallback); 
	ros::Subscriber sub2 = n2.subscribe("/base_scan", 10, SenzorCallback);
	ros::Subscriber sub3 = n3.subscribe("/map", 10, GridCallback);
	ros::Subscriber sub4 = n4.subscribe("/move_base_simple/goal", 10, GoalCallback);
	ros::Subscriber sub5 = n5.subscribe("/cmd_vel", 10, BrzinaCallback); 		
	
	ros::Rate(10);	
	while(ros::ok())
       {
         ros::spinOnce();
       }
	
}	
	
	
		
