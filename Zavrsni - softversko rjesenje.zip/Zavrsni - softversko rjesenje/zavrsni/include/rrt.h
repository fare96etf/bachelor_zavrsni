#include <iostream>
#include <vector>
#include <random>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/MapMetaData.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Pose.h>
#include <tf/transform_listener.h> 
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <Eigen/Dense>

#define PI 3.14159265358979323846264

using namespace std;
using namespace Eigen;
 
typedef vector<double> Koordinate;

int g(0);

// klasa Tacka

class Tacka {
    Koordinate koord;


public:
    Tacka *parent;
    Tacka(Koordinate k) { koord = k; parent = nullptr; }
    Koordinate Daj_Koordinate() {return koord;};
    void Dodijeli_Parent(Tacka *t) { parent = t;}
};

// klasa RRT

class RRT {

    vector<Tacka> Stablo;
    vector<Tacka> Putanja;
    nav_msgs::OccupancyGrid mapa;
    MatrixXi polja;
   	
    Koordinate Generisi_Koordinate(double delta, long int i, Koordinate goal);
    void Rekonstruisi_mapu();
    bool Provjeri_prepreke(Koordinate x);
    Tacka* Najbliza_tacka(Tacka t);
    double Izracunaj_udaljenost(Koordinate x, Koordinate y);
    double Random_generator();

public:
    
    //RRT(nav_msgs::OccupancyGrid mapa1) { mapa = mapa1; }
    void Generisi_Stablo(Tacka x_init,Tacka x_goal, double delta, long int broj_iteracija, nav_msgs::OccupancyGrid mapa1);
    void Ocisti_Stablo() { Stablo.clear(); }
    void Ocisti_Putanju() { Putanja.clear(); }
    int BrojTacakaStabla() {return Stablo.size(); }
    vector<Tacka> DajStablo () {return Stablo;}
    vector<Tacka> DajPutanju () {return Putanja;}

    double vrijeme;
    long int node;
    int it;		

};

// GLAVNA FUNKCIJA, generise stablo

void RRT::Generisi_Stablo(Tacka x_init,Tacka x_goal, double delta, long int broj_iteracija, nav_msgs::OccupancyGrid mapa1) {
    
    mapa = mapa1;
    Rekonstruisi_mapu();		
    Stablo.push_back(x_init);
    ROS_INFO ("Pocetna tacka-> x: %f, y: %f", x_init.Daj_Koordinate()[0], x_init.Daj_Koordinate()[1]);	
        	
    auto start = std::chrono::system_clock::now();	
    for (long int i = 0; i < broj_iteracija; i++) {
	    g = i;
            Tacka t(Generisi_Koordinate(delta, i, x_goal.Daj_Koordinate()));	
	    //if (Provjeri_prepreke(t.Daj_Koordinate()) == true) {
	    if (t.Daj_Koordinate().size() > 0) {	
            	t.Dodijeli_Parent(Najbliza_tacka(t));	
            	Stablo.push_back(t);
            	if (Izracunaj_udaljenost(t.Daj_Koordinate(), x_goal.Daj_Koordinate()) < delta) break;	
	    }

    }
    auto end = std::chrono::system_clock::now();

    std::chrono::duration<double> elapsed_seconds = end-start;
    std::time_t end_time = std::chrono::system_clock::to_time_t(end);
    
    vrijeme = elapsed_seconds.count();
    node = Stablo.size();
    it = g+1;	
    ROS_INFO ("elapsed time: %f", elapsed_seconds.count());			
    ROS_INFO ("broj node-ova: %lu, broj iteracija: %d", Stablo.size(), g+1);
    ROS_INFO ("Krajnja tacka-> x: %f, y: %f", Stablo[Stablo.size()-1].Daj_Koordinate()[0], Stablo[Stablo.size()-1].Daj_Koordinate()[1]);
    if (Izracunaj_udaljenost(Stablo[Stablo.size()-1].Daj_Koordinate(), x_goal.Daj_Koordinate()) < delta) ROS_INFO("Trazenje uspjesno!");
    else ROS_INFO("Trazenje neuspjesno!");		
    
    // nakon generisanog stabla nadje se putanja

    Tacka t (Stablo[Stablo.size()-1]);
    Putanja.push_back(t);
    while (t.parent != nullptr) {
        Putanja.push_back(*(t.parent));
        t = *(t.parent);
    }
    reverse(Putanja.begin(), Putanja.end());
}

// generisi koordinate

Koordinate RRT::Generisi_Koordinate(double delta, long int i, Koordinate goal) {
    
    Koordinate k;
    	
    if (i % 5 == 0) {
	k.push_back(goal[0]);
    	k.push_back(goal[1]);
    }
    else {	
    	k.push_back(Random_generator());
    	k.push_back(Random_generator());
    } 
    Tacka t(*Najbliza_tacka(k));

    double alpha (atan2(k[1]-t.Daj_Koordinate()[1], k[0]-t.Daj_Koordinate()[0]));
   	
    k[0] = t.Daj_Koordinate()[0] + delta*cos(alpha);
    k[1] = t.Daj_Koordinate()[1] + delta*sin(alpha);
    
    k[0]*=100; k[1]*=100;
    int k1 = int(k[0]); int k2 = int(k[1]);

    k[0] = double(k1)/100;
    k[1] = double(k2)/100;
       
    Koordinate k_pom({0, 0}); 
 
    double rezolucija(mapa.info.resolution);
    rezolucija*=100;		
    int r = int(rezolucija);
    rezolucija = double(r)/100;
	
    for (double j = rezolucija; j <= delta; j = j + rezolucija) {
	k_pom.clear();
	k_pom.push_back(t.Daj_Koordinate()[0] + j*cos(alpha));
	k_pom.push_back(t.Daj_Koordinate()[1] + j*sin(alpha));
	k_pom[0]*=100; k_pom[1]*=100;
    	int k_pom1 = int(k_pom[0]); int k_pom2 = int(k_pom[1]);

    	k_pom[0] = double(k_pom1)/100;
    	k_pom[1] = double(k_pom2)/100;
	//ROS_INFO("%f,  %f", k_pom[0], k_pom[1]);
        if (Provjeri_prepreke(k_pom) == false) { k.clear(); break; }
    }

    return k;
}


//provjeri prepreke preko OccupanyGrid msg

bool RRT::Provjeri_prepreke(Koordinate k) {
    bool istina(true);	

    /*double p (((double(mapa.info.width))*((k[1]-mapa.info.origin.position.y)/mapa.info.resolution-1))+((k[0]-mapa.info.origin.position.x)/mapa.info.resolution));
    //double p (((double(mapa.info.height))*((k[0]-mapa.info.origin.position.x)/mapa.info.resolution-1))+((k[1]-mapa.info.origin.position.y)/mapa.info.resolution));	
    long int prepreka = (long long)p; 	

    if (prepreka > mapa.info.width*mapa.info.height || mapa.data[prepreka] > 50 || mapa.data[prepreka] < 0) istina = false; */
    double pozicija_x ((k[0]-mapa.info.origin.position.x)/mapa.info.resolution);
    double pozicija_y ((k[1]-mapa.info.origin.position.y)/mapa.info.resolution);
    //ROS_INFO ("%f, %f", pozicija_x, pozicija_y);			
    if (polja(int(pozicija_y), int(pozicija_x)) == false) istina = false; 	
    return istina;
}

// odredi najblizu tacku iz stabla

Tacka* RRT::Najbliza_tacka(Tacka t) {
    double dmin = Izracunaj_udaljenost(Stablo[0].Daj_Koordinate(), t.Daj_Koordinate());
    Tacka *najbliza = new Tacka(Stablo[0]);

    for (int i = 1; i < Stablo.size(); i++) {

        if (Izracunaj_udaljenost(Stablo[i].Daj_Koordinate(), t.Daj_Koordinate()) < dmin) {
            dmin = Izracunaj_udaljenost(Stablo[i].Daj_Koordinate(), t.Daj_Koordinate());
            *najbliza = Stablo[i];
        }

    }

    return najbliza;
}

void RRT::Rekonstruisi_mapu() {
	MatrixXi polja1(0, 0);
	polja.resize(mapa.info.height, mapa.info.width);
	polja1.resize(mapa.info.height, mapa.info.width);
	for (int i = 0; i < mapa.info.height; i++) {
		for (int j = 0; j < mapa.info.width; j++) {
			if(mapa.data[i*mapa.info.height+j] > 50) polja1(i, j) = false;
			else if(mapa.data[i*mapa.info.height+j] < 0) polja1(i, j) = false;
			else polja1(i, j) = true;
			//polja(i, j) = (polja(i, j) && polja1(i, j)) || (!polja(i, j) && !polja1(i, j));
			polja(i, j) = polja1(i, j);
		}
	}
}


// pomocne funkcije i interfejs

double RRT::Izracunaj_udaljenost(Koordinate x, Koordinate y) {
    double d = 0;

    for (int i = 0; i < x.size(); i++) {
        d += (y[i]-x[i])*(y[i]-x[i]);
    }
    return sqrt(d);
}


double RRT::Random_generator() {
 
   std::random_device rd;  //Will be used to obtain a seed for the random number engine
   std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
   std::uniform_real_distribution<> dis(-10.0, 10.0);
   return dis(gen);
}
















