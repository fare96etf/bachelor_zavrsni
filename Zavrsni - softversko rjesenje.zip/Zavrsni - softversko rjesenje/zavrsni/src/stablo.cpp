#include "rrt.h"

using namespace std;

nav_msgs::Odometry polozaj;
nav_msgs::Odometry polozaj1;
nav_msgs::OccupancyGrid mapa;
geometry_msgs::PoseStamped GOAL;
geometry_msgs::PoseStamped GOAL_pomocna;
sensor_msgs::LaserScan senzor;
RRT rrt;

double Prosjek(vector<double> v) {
	double suma(0);
	for(int i = 0; i < v.size(); i++) {
		suma+=v[i];
	}
	return suma/double(v.size());
}

void OdomCallback(const nav_msgs::Odometry::ConstPtr& msg){
	polozaj = *msg;
		
	if (polozaj.pose.pose.position.x != polozaj1.pose.pose.position.x && polozaj.pose.pose.position.y != polozaj1.pose.pose.position.y) {
	//if (GOAL.pose.position.x != GOAL_pomocna.pose.position.x && GOAL.pose.position.y != GOAL_pomocna.pose.position.y) {
		polozaj1 = *msg;
		ros::NodeHandle n1;
		ros::NodeHandle n2;
		ros::Rate rate(1);
  		ros::Publisher marker_pub = n1.advertise<visualization_msgs::Marker>("visualization_marker", 1);
		ros::Publisher path_pub = n2.advertise<nav_msgs::Path>("/path", 1);
		

  		tf::TransformListener listener;
		tf::StampedTransform transform;
  
    			
    		try{
      			ros::Time now = ros::Time::now();
      			listener.waitForTransform("/map", "/odom", now, ros::Duration(1.0));
      			listener.lookupTransform("/map", "/odom", ros::Time(0), transform);
    		}
    		catch (tf::TransformException &ex) {
      			ROS_ERROR("%s",ex.what());
      			ros::Duration(0.5).sleep();
			ROS_INFO("Transformacija nije uspjela!");
		}
    	

		
		double odom_x (polozaj.pose.pose.position.x);
		double odom_y (polozaj.pose.pose.position.y);
		double pomak_x (transform.getOrigin().x());
		double pomak_y (transform.getOrigin().y());
		double R00 (transform.getBasis()[0][0]);
		double R01 (transform.getBasis()[0][1]);
		double R10 (transform.getBasis()[1][0]);
		double R11 (transform.getBasis()[1][1]); 
		Tacka t1 ({pomak_x + R00*odom_x+R01*odom_y, pomak_y + R10*odom_x+R11*odom_y});  		
		Tacka t2 ({GOAL.pose.position.x, GOAL.pose.position.y}); // goal tacka
		
		GOAL_pomocna = GOAL;  		
		
		try{ rrt.Generisi_Stablo(t1, t2, 3, 20000, mapa); }
		catch(exception e) {}		
		
		/*vector<double> vrijeme;
		vector<double> node;
                vector<double> iter; 
		for(int i = 0; i < 50; i++) {
			try{ rrt.Generisi_Stablo(t1, t2, 3, 20000, mapa); }
			catch(exception e) {}
			vrijeme.push_back(rrt.vrijeme);
			node.push_back(double(rrt.node));
			iter.push_back(double(rrt.it));
			rrt.Ocisti_Stablo();
			rrt.Ocisti_Putanju();
		}
		ROS_INFO("vrijeme: %f, node: %f, iter: %f, broj: %lu", Prosjek(vrijeme), Prosjek(node), Prosjek(iter), vrijeme.size());*/

		      		
		
		nav_msgs::Path putanja;
		putanja.header.frame_id = "/map";
		putanja.header.stamp = ros::Time::now();  		
		
		visualization_msgs::Marker points, line_list;
 		points.header.frame_id = line_list.header.frame_id = "/map";
   		points.header.stamp = line_list.header.stamp = ros::Time::now();
    		points.ns = line_list.ns = "points_and_lines";
   		points.action = line_list.action = visualization_msgs::Marker::ADD;
   		points.pose.orientation.w = line_list.pose.orientation.w = 1.0;

    		points.id = 0;
        	line_list.id = 2;

    		points.type = visualization_msgs::Marker::POINTS;
    		line_list.type = visualization_msgs::Marker::LINE_LIST;

    		points.scale.x = 0.2;
    		points.scale.y = 0.2;

    		line_list.scale.x = 0.01;

    		points.color.b = 1.0f;
    		points.color.a = 1.0;

    		line_list.color.r = 1.0f;
    		line_list.color.a = 1.0;

    		points.lifetime = ros::Duration();
		line_list.lifetime = ros::Duration();

      		geometry_msgs::Point p1;
		p1.x = rrt.DajStablo()[0].Daj_Koordinate()[0];
		p1.y = rrt.DajStablo()[0].Daj_Koordinate()[1];
      		p1.z = 0;
	

      		points.points.push_back(p1);
		
		geometry_msgs::PoseStamped pozicija;
		
		p1.x = rrt.DajPutanju()[0].Daj_Koordinate()[0];
		p1.y = rrt.DajPutanju()[0].Daj_Koordinate()[1];
	 
		pozicija.pose.position = p1;
		putanja.poses.push_back(pozicija);

    		for (int k = 1; k < rrt.DajStablo().size(); k++) {  // krece od 1 zato sto prvi parent je nullptr 

      			geometry_msgs::Point p;
			
			p.x = rrt.DajStablo()[k].Daj_Koordinate()[0];
			p.y = rrt.DajStablo()[k].Daj_Koordinate()[1];
      			p.z = 0;
			

      			points.points.push_back(p);
      			line_list.points.push_back(p);

			p.x = (rrt.DajStablo()[k].parent)->Daj_Koordinate()[0];
			p.y = (rrt.DajStablo()[k].parent)->Daj_Koordinate()[1];
      
      			line_list.points.push_back(p);

			if (k < rrt.DajPutanju().size()) {
				
				p.x = rrt.DajPutanju()[k].Daj_Koordinate()[0];
				p.y = rrt.DajPutanju()[k].Daj_Koordinate()[1];
				
				pozicija.pose.position = p;
				putanja.poses.push_back(pozicija);				
			}
    		}

		p1.x = t2.Daj_Koordinate()[0];
		p1.y = t2.Daj_Koordinate()[1];
      		p1.z = 0;
	

      		points.points.push_back(p1);

    		while (marker_pub.getNumSubscribers() < 1)
    		{
    
      			ROS_WARN_ONCE("Please create a subscriber to the marker");
     			sleep(1);
    		}
		
		rrt.Ocisti_Stablo();
		rrt.Ocisti_Putanju();
    		marker_pub.publish(points);
    		marker_pub.publish(line_list);
		path_pub.publish(putanja);
	
	} // kraj if petlje	

}

void GridCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg){
	mapa = *msg;
	
}


void SenzorCallback(const sensor_msgs::LaserScan::ConstPtr& msg){
	senzor = *msg;	
}

void GoalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg){
	GOAL = *msg;	
}


int main( int argc, char** argv )
{
  
	ros::init(argc, argv, "stablo");
  	ros::NodeHandle n;
 	ros::Subscriber sub1 = n.subscribe("/odom",1, OdomCallback); 
  	ros::Subscriber sub2 = n.subscribe("/base_link",1, SenzorCallback);
	ros::Subscriber sub3 = n.subscribe("/map",1, GridCallback);
	ros::Subscriber sub4 = n.subscribe("/move_base_simple/goal",1, GoalCallback); 		
	
  	ros::spin();

}



